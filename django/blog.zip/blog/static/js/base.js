document.querySelector("#logout").addEventListener("click", (e) => {
  e.preventDefault();
  document.querySelector("#logoutForm").submit();
});
